import express from 'express';
import {registerUser} from '../controllers/registerUser.js'
import {loginUser} from '../controllers/loginUser.js'
import {logoutUser} from '../controllers/logout.js'
const userRouter = express.Router();

userRouter.post('/register', registerUser);
userRouter.post('/login', loginUser);
userRouter.post('/logout', logoutUser);

export default userRouter;