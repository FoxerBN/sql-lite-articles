import db from '../config/database.js';

export const getPaginatedPosts = (req, res) => {
    const { page = 0 } = req.query; 
    const pageIndex = parseInt(page, 10);

    if (isNaN(pageIndex) || pageIndex < 0) {
        return res.status(400).json({ message: 'Invalid page parameter. Ensure it is a non-negative number.' });
    }

    const offset = pageIndex * 10;

    const query = `SELECT * FROM posts LIMIT 10 OFFSET ?`;
    const posts = db.prepare(query).all(offset);

    res.json({
        message: `Fetched ${posts.length} posts for page ${pageIndex}.`,
        posts,
    });
};
